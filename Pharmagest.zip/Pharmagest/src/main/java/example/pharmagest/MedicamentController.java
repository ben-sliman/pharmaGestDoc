package example.pharmagest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class MedicamentController implements Initializable {
    Connection con = null ;
    PreparedStatement st = null ;
    ResultSet rs = null;
    @FXML
    private Button btnClear;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnUpdate;

    @FXML
    private TableColumn<Medicament, String> colDci;

    @FXML
    private TableColumn<Medicament, String> colDosage;

    @FXML
    private TableColumn<Medicament, String> colForme;

    @FXML
    private TableColumn<Medicament, String> colNom;

    @FXML
    private TableColumn<Medicament, String> colPeremption;

    @FXML
    private TableColumn<Medicament, Double> colPrix;

    @FXML
    private TableColumn<Medicament, Integer> colStock;

    @FXML
    private TableColumn<Medicament, Integer> colid;

    @FXML
    private DatePicker date_peremption;

    @FXML
    private TextField dci;

    @FXML
    private TextField dosage;

    @FXML
    private TextField forme;

    @FXML
    private TextField nom;

    @FXML
    private TextField prix;

    @FXML
    private TextField quantite;

    @FXML
    private TableView<Medicament> table;

    int id = 0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showUser();
    }

    public ObservableList<Medicament> getMedicaments(){
        ObservableList<Medicament> medicaments = FXCollections.observableArrayList();

        String query = "select * from medicament";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(query);
            rs = st.executeQuery();
            while (rs.next()){
                Medicament st = new Medicament();
                st.setId(rs.getInt("id"));
                st.setDci(rs.getString("dci"));
                st.setNom(rs.getString("nom"));
                st.setDosage(rs.getString("dosage"));
                st.setForme(rs.getString("forme"));
                st.setPrix(rs.getDouble("prix"));
                st.setDate_peremption(rs.getString("date_peremption"));
                st.setStock(rs.getInt("stock"));
                medicaments.add(st);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return medicaments;
    }

    public void showUser(){
        ObservableList<Medicament>list = getMedicaments();
        table.setItems(list);
        colid.setCellValueFactory(new PropertyValueFactory<Medicament, Integer>("id"));
        colDci.setCellValueFactory(new PropertyValueFactory<Medicament, String>("dci"));
        colNom.setCellValueFactory(new PropertyValueFactory<Medicament, String>("nom"));
        colDosage.setCellValueFactory(new PropertyValueFactory<Medicament, String>("dosage"));
        colForme.setCellValueFactory(new PropertyValueFactory<Medicament, String>("forme"));
        colPrix.setCellValueFactory(new PropertyValueFactory<Medicament, Double>("prix"));
        colPeremption.setCellValueFactory(new PropertyValueFactory<Medicament, String>("date_peremption"));
        colStock.setCellValueFactory(new PropertyValueFactory<Medicament, Integer>("stock"));
    }

    @FXML
    void addUser(ActionEvent event) {
        String insert = "INSERT INTO medicament(dci, nom, dosage, forme, prix, date_peremption, stock) VALUES (?, ?, ?, ?, ?, ?, ?)";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(insert);
            st.setString(1, dci.getText());
            st.setString(2, nom.getText());
            st.setString(3, dosage.getText());
            st.setString(4, forme.getText());
            st.setDouble(5, Double.parseDouble(prix.getText()));

            // Convertir la date au format "jour-mois-année"
            LocalDate datePeremption = date_peremption.getValue();
            String datePeremptionFormattee = String.format("%02d-%02d-%04d", datePeremption.getDayOfMonth(), datePeremption.getMonthValue(), datePeremption.getYear());
            st.setString(6, datePeremptionFormattee);

            st.setInt(7, 0); // Définir le stock initial à 0
            st.executeUpdate();
            showUser();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }



    @FXML
    void clear(ActionEvent event) {

    }

    @FXML
    void deleteUser(ActionEvent event) {

    }

    @FXML
    void getData(MouseEvent event) {
        Medicament medicament = table.getSelectionModel().getSelectedItem();
        id = medicament.getId();
        dci.setText(medicament.getDci());
        nom.setText(medicament.getNom());
        dosage.setText(medicament.getDosage());
        forme.setText(medicament.getForme());
        prix.setText(String.valueOf(medicament.getPrix()));
        LocalDate datePeremption = LocalDate.parse(medicament.getDate_peremption());
        date_peremption.setValue(datePeremption);
        btnSave.setDisable(true);
    }


    @FXML
    void updateUser(ActionEvent event) {

    }
}
