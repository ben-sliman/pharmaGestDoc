package example.pharmagest;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;

public class VenteController {

    @FXML
    private Button ajouter;

    @FXML
    private Button btnAnnuler;

    @FXML
    private Button btnValider;

    @FXML
    private DatePicker date;

    @FXML
    private ChoiceBox<?> listeMed;

    @FXML
    private TableColumn<?, ?> medicament;

    @FXML
    private TextField nomMedecin;

    @FXML
    private TextField nomPatient;

    @FXML
    private TextField numPrescription;

    @FXML
    private CheckBox ordonnance;

    @FXML
    private TableColumn<?, ?> prixUnit;

    @FXML
    private TextField qttMed;

    @FXML
    private TableColumn<?, ?> qttVendue;

    @FXML
    private CheckBox sansOrdonnance;

    @FXML
    private Label total;

    @FXML
    private TableColumn<?, ?> totalMed;

    @FXML
    private TableColumn<?, ?> unite;

}
