package example.pharmagest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.sql.SQLException;
public class VenteController implements Initializable {

    Connection con = null ;
    PreparedStatement st = null ;
    ResultSet rs = null;

    @FXML
    private Button ajouter;

    @FXML
    private Button btnAnnuler;

    @FXML
    private Button btnValider;

    @FXML
    private TableColumn<Vente, String> colNom;

    @FXML
    private TableColumn<Vente, Integer> colNum;

    @FXML
    private TableColumn<Vente, Double> colPrix;

    @FXML
    private TableColumn<Vente, Double> colPrixTotal;

    @FXML
    private TableColumn<Vente, Integer> colQuantité;

    @FXML
    private DatePicker date;

    @FXML
    private Label idVente;

    @FXML
    private Label labelTotal;

    @FXML
    private ComboBox<String> listeMed;

    @FXML
    private TextField nomMedecin;

    @FXML
    private TextField nomPatient;

    @FXML
    private TextField numPrescription;

    @FXML
    private CheckBox ordonnance;

    @FXML
    private TextField quantite;

    @FXML
    private CheckBox sansOrdonnance;

    @FXML
    private TableView<Vente> table;
    private int dernierNum = 0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        colNom.setCellValueFactory(new PropertyValueFactory<Vente, String>("nomPatient"));
        colNum.setCellValueFactory(new PropertyValueFactory<Vente, Integer>("dernierNum"));
        colPrix.setCellValueFactory(new PropertyValueFactory<Vente, Double>("prixMedicament"));
        colPrixTotal.setCellValueFactory(new PropertyValueFactory<Vente, Double>("prixTotal"));
        colQuantité.setCellValueFactory(new PropertyValueFactory<Vente, Integer>("quantite"));
        remplirComboBox();
    }


    void calculPrixTotal() {
        for (Vente vente : table.getItems()) {
            double prixTotal = vente.getQuantite() * vente.getColPrix();
            vente.setColPrixTotal(prixTotal);
        }
        table.refresh();
    }

    void calculTotal (){
        double somme = 0;
        for (int i = 0; i < table.getItems().size(); i++) {
            somme += table.getItems().get(i).getColPrixTotal();
        }
        labelTotal.setText(String.valueOf(somme));
    }

     void remplirComboBox(){
        String query = "SELECT nom FROM medicament";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(query);
            rs = st.executeQuery();
            while (rs.next()){
                String nom = rs.getString("nom").toString();
                listeMed.getItems().add(nom);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    void valider(ActionEvent event) {
        String insert = "insert into ticket(nom,date,ptix_total) values (?,?,?)";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(insert);
            st.setString(1, nomPatient.getText());
            // Récupérer la date actuelle
            String currentDate = java.time.LocalDate.now().toString();
            st.setString(2, currentDate);
            st.setString(3, labelTotal.getText());
            st.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void ajouter(ActionEvent event) {
        String nomMedicament = listeMed.getValue();
        int quantiteMedicament = Integer.parseInt(quantite.getText());

        // Récupérer le prix du médicament sélectionné
        String query = "SELECT prix FROM medicament WHERE nom = ?";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(query);
            st.setString(1, nomMedicament);
            rs = st.executeQuery();
            if (rs.next()){
                double prixMedicament = rs.getDouble("prix");

                // Créer un nouvel objet Vente et l'ajouter à la table
                Vente vente = new Vente();
                vente.setListMed(nomMedicament);
                vente.setQuantite(quantiteMedicament);
                vente.setColPrix(prixMedicament);
                vente.setColPrixTotal(quantiteMedicament * prixMedicament);
                vente.setColNum(++dernierNum); // Ajout de cette ligne
                table.getItems().add(vente);
            }
            calculPrixTotal();
            calculTotal();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }





}
