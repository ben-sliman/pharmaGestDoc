package example.pharmagest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBcon {
    static String user = "postgres";
    static String password = "nichico976";
    static String url = "jdbc:postgresql://localhost:5432/CRUD_DB";
    static String driver = "org.postgresql.Driver";

    public static Connection getCon (){
        Connection con = null;
        try {
            Class.forName(driver);
            try {
                con = DriverManager.getConnection(url,user,password);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return con;
    }
}
