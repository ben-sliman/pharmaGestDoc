package example.pharmagest;

public class Vente {
    private int id;
    private String nomMedecin;
    private String nomPatient;
    private int numPrescription;
    private String date;
    private int quantite;
    private String ordonnance;
    private String sansOrdonnance;
    private String listMed;
    private double colPrixTotal;
    private double colPrix;

    public int getColNum() {

        return colNum;
    }

    public void setColNum(int colNum) {
        this.colNum = colNum;
    }

    private int colNum;
    public double getColPrix() {
        return colPrix;
    }

    public void setColPrix(double colPrix) {
        this.colPrix = colPrix;
    }

    public double getColPrixTotal() {
        return colPrixTotal;
    }

    public void setColPrixTotal(double colPrixTotal) {
        this.colPrixTotal = colPrixTotal;
    }


    public String getListMed() {
        return listMed;
    }

    public void setListMed(String listMed) {
        this.listMed = listMed;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomMedecin() {
        return nomMedecin;
    }

    public void setNomMedecin(String nomMedecin) {
        this.nomMedecin = nomMedecin;
    }

    public String getNomPatient() {
        return nomPatient;
    }

    public void setNomPatient(String nomPatient) {
        this.nomPatient = nomPatient;
    }

    public int getNumPrescription() {
        return numPrescription;
    }

    public void setNumPrescription(int numPrescription) {
        this.numPrescription = numPrescription;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public String getOrdonnance() {
        return ordonnance;
    }

    public void setOrdonnance(String ordonnance) {
        this.ordonnance = ordonnance;
    }

    public String getSansOrdonnance() {
        return sansOrdonnance;
    }

    public void setSansOrdonnance(String sansOrdonnance) {
        this.sansOrdonnance = sansOrdonnance;
    }

}
