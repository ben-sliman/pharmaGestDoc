package example.pharmagest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

public class caisseController {

    @FXML
    private Button Fermer;

    @FXML
    private TableColumn<?, ?> M_APayer;

    @FXML
    private Label M_Remis;

    @FXML
    private TableColumn<?, ?> NumVente;

    @FXML
    private Label Rendue;

    @FXML
    private ComboBox<String> payemenType; // Modifier le type de ComboBox en String

    @FXML
    void initialize() {
        // Initialiser la ComboBox avec les options "Espèce" et "Carte bancaire"
        ObservableList<String> paymentOptions = FXCollections.observableArrayList("Espèce", "Carte bancaire");
        payemenType.setItems(paymentOptions);
    }

    @FXML
    void onCloseButtonClick(ActionEvent event) {
        // Ajouter le code à exécuter lors de la fermeture
    }
}
