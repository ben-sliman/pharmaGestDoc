package example.pharmagest;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.fxml.Initializable;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class UtilisateurController implements Initializable  {

    Connection con = null ;
    PreparedStatement st = null ;
    ResultSet rs = null;

    @FXML
    private Button btnClear;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnSave;

    @FXML
    private Button btnUpdate;

    @FXML
    private TextField identifiant;

    @FXML
    private TextField mdp;

    @FXML
    private TextField nom;

    @FXML
    private TextField prenom;


    @FXML
    private TableColumn<Utilisateur, String> colMdp;

    @FXML
    private TableColumn<Utilisateur, String> colNom;

    @FXML
    private TableColumn<Utilisateur, String> colPrenom;

    @FXML
    private TableColumn<Utilisateur, Integer> colid;

    @FXML
    private TableColumn<Utilisateur, String> colidentifiant;

    @FXML
    private TableView<Utilisateur> table;
    int id = 0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showUser();
    }

    public ObservableList<Utilisateur> getUtilisateurs(){
        ObservableList<Utilisateur> utilisateurs = FXCollections.observableArrayList();

        String query = "select * from utilisateur";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(query);
            rs = st.executeQuery();
            while (rs.next()){
                Utilisateur st = new Utilisateur();
                st.setId(rs.getInt("id"));
                st.setNom(rs.getString("Nom"));
                st.setPrenom(rs.getString("Prenom"));
                st.setIdentifiant(rs.getString("Identifiant"));
                st.setMdp(rs.getString("Mdp"));
                utilisateurs.add(st);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return utilisateurs;
    }

    public void showUser(){
        ObservableList<Utilisateur>list = getUtilisateurs();
        table.setItems(list);
        colid.setCellValueFactory(new PropertyValueFactory<Utilisateur, Integer>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<Utilisateur, String>("Nom"));
        colPrenom.setCellValueFactory(new PropertyValueFactory<Utilisateur, String>("Prenom"));
        colidentifiant.setCellValueFactory(new PropertyValueFactory<Utilisateur, String>("Identifiant"));
        colMdp.setCellValueFactory(new PropertyValueFactory<Utilisateur, String>("Mdp"));
    }

    @FXML
    void addUser(ActionEvent event) {
        String insert = "insert into utilisateur(nom,prenom,identifiant,mdp) values (?,?,?,?)";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(insert);
            st.setString(1, nom.getText());
            st.setString(2, prenom.getText());
            st.setString(3, identifiant.getText());
            st.setString(4, mdp.getText());
            st.executeUpdate();
            clear();
            showUser();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void getData(MouseEvent event) {
        Utilisateur utilisateur = table.getSelectionModel().getSelectedItem();
        id = utilisateur.getId();
        nom.setText(utilisateur.getNom());
        prenom.setText(utilisateur.getPrenom());
        identifiant.setText(utilisateur.getIdentifiant());
        mdp.setText(utilisateur.getMdp());
        btnSave.setDisable(true);
    }

    @FXML
    void clear(ActionEvent event) {
        clear();
    }

    void clear(){
        nom.setText(null);
        prenom.setText(null);
        identifiant.setText(null);
        mdp.setText(null);
        btnSave.setDisable(false);
    }

    @FXML
    void deleteUser(ActionEvent event) {
        String delete = "delete from utilisateur where id = ?";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(delete);
            st.setInt(1, id);
            st.executeUpdate();
            clear();
            showUser();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void updateUser(ActionEvent event) {
        String update = "update utilisateur set nom = ?, prenom = ?, identifiant = ?, mdp = ? where id = ?";
        con = DBcon.getCon();
        try {
            st = con.prepareStatement(update);
            st.setString(1, nom.getText());
            st.setString(2, prenom.getText());
            st.setString(3, identifiant.getText());
            st.setString(4, mdp.getText());
            st.setInt(5, id);
            st.executeUpdate();
            clear();
            showUser();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
